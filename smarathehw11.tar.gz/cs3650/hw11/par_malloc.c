// Initial Author: Sourabh Marathe

#include <stdio.h>
#include <string.h>

#include "hw06_opt.h"
#include "xmalloc.h"

void* xmalloc(size_t bytes) {
    return hw06_opt_malloc(bytes);
}

void xfree(void* ptr) {
    hw06_opt_free(ptr);
}

void* xrealloc(void* prev, size_t bytes) {
    void* new = hw06_opt_malloc(bytes);
    int64_t prev_bytes = *((int64_t*) (prev - sizeof(int64_t)));
    memcpy(new, prev, prev_bytes);
    hw06_opt_free(prev);
    return new;
}
