#ifndef HW06_MEM_H
#define HW06_MEM_H
// Initial Author: Matthew Murphy

#include <stdint.h>

void* hw06_malloc(size_t size);
void hw06_free();

#endif
