// Initial Author: Sourabh Marathe
// Edited By: Matthew Murphy

#include <stdint.h>
#include <sys/mman.h>
#include <assert.h>
#include <pthread.h>
#include <stdio.h>

#include "hw06_mem.h"

typedef struct nu_free_cell {
    int64_t              size;
    struct nu_free_cell* next;
} nu_free_cell;

static void nu_free_list_insert(nu_free_cell* cell, int index, int should_coalesce);
static void nu_free_list_coalesce(int index); 
static nu_free_cell* free_list_get_cell(int64_t size, int index);

static const int64_t CHUNK_SIZE = 65536;
static const int64_t CELL_SIZE  = (int64_t)sizeof(nu_free_cell);

static const int BASE_FREE_LIST_LENGTH = 5;

static const int FREE_LIST_SIZE = 256; 
static __thread  nu_free_cell* nu_free_list[256] = {0};
static __thread int nu_free_list_size[256] = {0}; 
// Global free list.
static nu_free_cell* nu_global_free_list = 0;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

static void nu_mem_lock() {
    pthread_mutex_lock(&mutex);
}

static void nu_mem_unlock() {
    pthread_mutex_unlock(&mutex);
}


static int nu_free_list_length(int max_length, int index) {
    int len = nu_free_list_size[index];
	if (len > max_length) {
		return 1; 
	} else {
		return 0; 
	}
}

static int nu_get_power_of_two(int64_t input_int) {
    int return_val = 0;
    int dividing_num = 336;
    int64_t iter = 1;
    while (iter < input_int && iter <= 1024) {
        return_val++;
        iter += 16;
        // This uses 64 of the spaces. That leaves us with 256 - 64 left. 
    }
    if (iter > input_int) {
        return return_val;
    }
    while (iter < input_int) {
        return_val++;
        iter += dividing_num;
    }
    return return_val;
}

static void nu_actual_coalesce() {
    nu_mem_lock();
    nu_free_cell* pp = nu_global_free_list;
    int free_chunk = 0;

    while (pp != 0 && pp->next != 0) {
        if (((int64_t)pp) + pp->size == ((int64_t) pp->next)) {
            pp->size += pp->next->size;
            pp->next  = pp->next->next;
        }
        pp = pp->next;
    }
    nu_mem_unlock();
}

static void nu_free_list_insert(nu_free_cell* cell, int index, int should_coalesce) {
	nu_free_list_size[index] = nu_free_list_size[index] + 1;
    if (nu_free_list[index] == 0 || ((uint64_t) nu_free_list[index]) > ((uint64_t) cell)) {
        cell->next = nu_free_list[index];
        nu_free_list[index] = cell;
        return;
    }

    nu_free_cell* pp = nu_free_list[index];

    while (pp->next != 0 && ((uint64_t)pp->next) < ((uint64_t) cell)) {
        pp = pp->next;
    }

    cell->next = pp->next;
    pp->next = cell;

	if (should_coalesce) {
		nu_free_list_coalesce(index); 
	}
}

static void nu_global_free_list_insert(nu_free_cell* cell) {
    nu_mem_lock();
    if (nu_global_free_list == 0 || ((uint64_t) nu_global_free_list) > ((uint64_t) cell)) {
        cell->next = nu_global_free_list;
        nu_global_free_list = cell;
        nu_mem_unlock();
        return;
    }

    nu_free_cell* pp = nu_global_free_list;

    while (pp->next != 0 && ((uint64_t)pp->next) < ((uint64_t) cell)) {
        pp = pp->next;
    }

    cell->next = pp->next;
    pp->next = cell;
    nu_mem_unlock();
}

static nu_free_cell* free_global_list_get_cell(int64_t size) {
    nu_mem_lock();
    nu_free_cell** prev = &nu_global_free_list;
    for (nu_free_cell* pp = nu_global_free_list; pp != 0; pp = pp->next) {
        if (pp->size >= size) {
            *prev = pp->next;
            nu_mem_unlock();
            return pp;
        }
        prev = &(pp->next);
    }
    nu_mem_unlock();
    return 0;
}

static void nu_free_list_coalesce(int index) {
	if (index != FREE_LIST_SIZE - 1) {
		int max_length = BASE_FREE_LIST_LENGTH * (256 - index); 		
		if (nu_free_list_length(max_length, index)) {
            int cells_to_remove = max_length / 2;
            for (int ii = 0; ii < cells_to_remove; ii++) {
                nu_free_cell* pp = free_list_get_cell(0, index);
                if (pp) {
                    nu_global_free_list_insert(pp);
                }
            }
            nu_actual_coalesce();
		}
	}
}

static nu_free_cell* free_list_get_cell(int64_t size, int index) {
	while (index < FREE_LIST_SIZE) {
		nu_free_cell** prev = &nu_free_list[index];
		for (nu_free_cell* pp = nu_free_list[index]; pp != 0; pp = pp->next) {
			if (pp->size >= size) {
				*prev = pp->next;
				nu_free_list_size[index] = nu_free_list_size[index] - 1; 
				assert(nu_free_list_size[index] >= 0); 
				return pp;
			}
			prev = &(pp->next);
		}
		index = index + 1; 
	}
    return 0;
}

static nu_free_cell* make_cell() {
    void* addr = mmap(0, CHUNK_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    nu_free_cell* cell = (nu_free_cell*) addr; 
    cell->size = CHUNK_SIZE;
    return cell;
}

void* hw06_opt_malloc(size_t usize) {
    int64_t size = (int64_t) usize;

    // space for size
    int64_t alloc_size = size + sizeof(int64_t);

    // space for free cell when returned to list
    if (alloc_size < CELL_SIZE) {
        alloc_size = CELL_SIZE;
    }

    // TODO: Handle large allocations.
    if (alloc_size > CHUNK_SIZE) {
        void* addr = mmap(0, alloc_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        *((int64_t*)addr) = alloc_size;
        return addr + sizeof(int64_t);
    }
	int index = nu_get_power_of_two(alloc_size);
    nu_free_cell* cell = free_list_get_cell(alloc_size, index);
    if (!cell) {
        cell = free_global_list_get_cell(alloc_size);
        if (!cell) {
            cell = make_cell();
        }
    }

    // Return unused portion to free list.
    int64_t rest_size = cell->size - alloc_size;
    if (rest_size >= CELL_SIZE) {
        void* addr = (void*) cell;
        nu_free_cell* rest = (nu_free_cell*) (addr + alloc_size);
        rest->size = rest_size;
		int rest_index = nu_get_power_of_two(rest_size);
        // Nu_get_power_of_two returns the power of two that is greater than
        // or equal to the size. We want something that is always smaller.
        // So if it is greater than zero subtract one.
        if (rest_index > 0) {
            rest_index -= 1;
        }
        nu_free_list_insert(rest, rest_index, 1);
    }

    *((int64_t*)cell) = alloc_size;
    return ((void*)cell) + sizeof(int64_t);
}

void hw06_opt_free(void* addr)  {
    nu_free_cell* cell = (nu_free_cell*)(addr - sizeof(int64_t));
    int64_t size = *((int64_t*) cell);

    if (size > CHUNK_SIZE) {
        munmap((void*) cell, size);
    }
    else {
        cell->size = size;
		int index = nu_get_power_of_two(size); 
        nu_free_list_insert(cell, index, 1);
    }
}
