// Initial Author: Sourabh Marathe
// Edited By: Matthew Murphy

#ifndef HW06_OPT_H
#define HW06_OPT_H

#include <stdint.h>

void* hw06_opt_malloc(size_t size);
void hw06_opt_free();

#endif
