sort < tests/sample.txt
